import random

def escolher_palavra():
    palavras = ['python', 'java', 'ruby', 'javascript', 'php', 'swift']
    return random.choice(palavras)

def jogar_forca():
    nome_jogador = input("Digite seu nome: ")
    palavra = escolher_palavra()
    letras_corretas = set(palavra)
    letras_digitadas = set()
    tentativas_restantes = 6
    
    print("Bem-vindo ao Jogo da Forca!")
    print(f"{nome_jogador}, tente adivinhar a palavra secreta.")
    
    while tentativas_restantes > 0:
        palavra_mostrada = ''.join(letra if letra in letras_digitadas else '_' for letra in palavra)
        print(f"Palavra: {palavra_mostrada}")
        print(f"Tentativas restantes: {tentativas_restantes}")
        
        # Verifica se todas as letras corretas foram adivinhadas
        if all(letra in letras_digitadas for letra in letras_corretas):
            print(f"Parabéns, {nome_jogador}! Você ganhou!")
            salvar_ranking(nome_jogador, tentativas_restantes)
            return
        
        letra = input("Digite uma letra: ").lower()
        
        if letra in letras_digitadas:
            print("Você já digitou essa letra. Tente outra.")
        else:
            letras_digitadas.add(letra)
            if letra not in letras_corretas:
                tentativas_restantes -= 1
                print(f"A letra '{letra}' não está na palavra.")
    
    # Fora do loop, após as tentativas se esgotarem
    else:
        print(f"Que pena, você perdeu! A palavra era '{palavra}'.")
        salvar_ranking(nome_jogador, 0)

def salvar_ranking(nome_jogador, pontuacao):
    with open('ranking.csv', 'a') as arquivo:
        arquivo.write(f"{nome_jogador}: {pontuacao}\n")

def exibir_ranking():
    print("=== RANKING ===")
    with open('ranking.csv', 'r') as arquivo:
        ranking = arquivo.readlines()
        ranking = [linha.strip() for linha in ranking]
        ranking.sort(key=lambda x: int(x.split(': ')[1]), reverse=True)
        for posicao, linha in enumerate(ranking, start=1):
            print(f"{posicao}. {linha}")

# Exemplo de uso do jogo:
jogar_forca()
exibir_ranking()
